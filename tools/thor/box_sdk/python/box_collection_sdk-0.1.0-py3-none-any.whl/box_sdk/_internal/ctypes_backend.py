from __future__ import annotations

import ctypes as C
from ctypes import (
    c_uint8,
    c_uint16,
    c_uint32,
    c_size_t,
    c_char_p,
    c_float,
    c_double,
    c_int32,
    c_void_p,
)
from importlib import resources


def _default_lib_path() -> str:
    # wheel 内路径：box_sdk/lib/libbox_controller.so
    so = resources.files("box_sdk").joinpath("lib/libbox_controller.so")
    return str(so)


class UdpConfig(C.Structure):
    _fields_ = [
        ("bind_ip", c_char_p),
        ("bind_port", c_uint16),
        ("remote_ip", c_char_p),
        ("remote_port", c_uint16),
    ]


class GripperData(C.Structure):
    _pack_ = 1
    class DistanceUnion(C.Union):
        _pack_ = 1
        _fields_ = [("as_float", c_float), ("as_int32", c_int32)]

    _fields_ = [("timestamp", c_uint32), ("distance_raw", DistanceUnion)]

    @property
    def distance(self) -> float:
        return float(self.distance_raw.as_float)

    @property
    def distance_int32(self) -> int:
        return int(self.distance_raw.as_int32)


class ImuData(C.Structure):
    _pack_ = 1
    _fields_ = [
        ("timestamp", c_uint32),
        ("acc", c_float * 3),
        ("gyr", c_float * 3),
        ("roll", c_float),
        ("pitch", c_float),
        ("yaw", c_float),
        ("quat", c_float * 4),
    ]


class TriggerData(C.Structure):
    _pack_ = 1
    _fields_ = [("timestamp", c_uint32), ("distance", c_float)]


class SixDForceData(C.Structure):
    _pack_ = 1
    _fields_ = [("timestamp", c_uint32), ("data", c_float * 6)]


class TouchForce(C.Structure):
    _pack_ = 1
    _fields_ = [("fx", C.c_int8), ("fy", C.c_int8), ("fz", C.c_uint8)]


class TouchSensor(C.Structure):
    _pack_ = 1
    _fields_ = [("timestamp", c_uint32), ("forces", TouchForce * 239)]


class AllSensor(C.Structure):
    _pack_ = 1
    _fields_ = [
        ("gripper_data", GripperData),
        ("imu_data", ImuData),
        ("trigger_data", TriggerData),
        ("six_d_force_data", SixDForceData),
        ("touch_sensor_data_first", TouchSensor),
        ("touch_sensor_data_sec", TouchSensor),
    ]


class SensorCache(C.Structure):
    _pack_ = 1
    _fields_ = [
        ("valid", c_uint8),
        ("_reserved", c_uint8 * 3),
        ("liwp_index", c_uint32),
        ("liwp_timestemp", c_uint32),
        ("data", AllSensor),
        ("touch_sensor_data", TouchSensor * 2),
    ]


class DecodedPacket(C.Structure):
    _fields_ = [
        ("index", c_uint32),
        ("timestemp", c_uint32),
        ("length", c_uint16),
        ("type", c_uint16),
        ("payload", C.POINTER(c_uint8)),
        ("payload_len", c_size_t),
    ]


PACKET_OBSERVER_CB = C.CFUNCTYPE(None, c_void_p, C.POINTER(DecodedPacket))


class _Lib:
    def __init__(self, so_path: str | None = None):
        self._so_path = so_path or _default_lib_path()
        self._cdll = C.CDLL(self._so_path)
        self._bind()

    @property
    def cdll(self):
        return self._cdll

    def _bind(self):
        lib = self._cdll

        lib.box_create.restype = c_void_p
        lib.box_destroy.argtypes = [c_void_p]

        lib.box_start.argtypes = [c_void_p, C.POINTER(UdpConfig), C.c_char_p, c_size_t]
        lib.box_start.restype = c_int32

        lib.box_stop.argtypes = [c_void_p]

        lib.box_get_box_sensor_data.argtypes = [c_void_p, C.POINTER(SensorCache)]
        lib.box_get_box_sensor_data.restype = c_int32

        lib.box_get_mode.argtypes = [c_void_p, C.POINTER(c_uint8), c_uint32]
        lib.box_get_mode.restype = c_int32

        lib.box_get_gripper_pos.argtypes = [c_void_p, C.POINTER(c_float), c_uint32]
        lib.box_get_gripper_pos.restype = c_int32

        lib.box_set_mode.argtypes = [c_void_p, c_uint8]
        lib.box_set_mode.restype = c_int32

        lib.box_set_clamp_pos.argtypes = [c_void_p, c_double]
        lib.box_set_clamp_pos.restype = c_int32

        lib.box_set_trigger_zero.argtypes = [c_void_p]
        lib.box_set_trigger_zero.restype = c_int32

        lib.box_set_packet_observer.argtypes = [c_void_p, c_void_p, c_void_p]
        lib.box_set_packet_observer.restype = None

        lib.error_message_c.argtypes = [c_int32]
        lib.error_message_c.restype = c_char_p


class Box:
    def __init__(self, so_path: str | None = None):
        self._lib = _Lib(so_path)
        self._h = self._lib.cdll.box_create()
        self._observer_cfunc = None
        self._observer_user = c_void_p(0)
        if not self._h:
            raise RuntimeError("box_create failed")

    def close(self):
        if self._h:
            self._lib.cdll.box_destroy(self._h)
            self._h = None

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass

    def start(self, bind_ip: str, bind_port: int, remote_ip: str, remote_port: int) -> int:
        cfg = UdpConfig(
            bind_ip=bind_ip.encode(),
            bind_port=int(bind_port),
            remote_ip=remote_ip.encode(),
            remote_port=int(remote_port),
        )
        err = C.create_string_buffer(256)
        rc = int(self._lib.cdll.box_start(self._h, C.byref(cfg), err, C.sizeof(err)))
        if rc != 0:
            raise RuntimeError(f"box_start failed: {err.value.decode('utf-8', 'ignore')}")
        return rc

    def stop(self):
        self._lib.cdll.box_stop(self._h)

    def get_sensor_cache(self) -> tuple[int, SensorCache]:
        snap = SensorCache()
        rc = int(self._lib.cdll.box_get_box_sensor_data(self._h, C.byref(snap)))
        return rc, snap

    def get_mode(self, timeout_ms: int = 100) -> tuple[int, int]:
        mode = c_uint8(0)
        rc = int(self._lib.cdll.box_get_mode(self._h, C.byref(mode), int(timeout_ms)))
        return rc, int(mode.value)

    def get_gripper_pos(self, timeout_ms: int = 100) -> tuple[int, float]:
        pos_cm = c_float(0.0)
        rc = int(self._lib.cdll.box_get_gripper_pos(self._h, C.byref(pos_cm), int(timeout_ms)))
        return rc, float(pos_cm.value)

    def set_mode(self, mode: int) -> int:
        return int(self._lib.cdll.box_set_mode(self._h, int(mode)))

    def set_clamp_pos(self, pos_m: float) -> int:
        return int(self._lib.cdll.box_set_clamp_pos(self._h, float(pos_m)))

    def set_trigger_zero(self) -> int:
        return int(self._lib.cdll.box_set_trigger_zero(self._h))

    def set_packet_observer(self, callback, user_data: int = 0):
        if callback is None:
            self._observer_cfunc = None
            self._observer_user = c_void_p(0)
            self._lib.cdll.box_set_packet_observer(self._h, c_void_p(0), c_void_p(0))
            return

        self._observer_user = c_void_p(int(user_data))

        def _bridge(user, packet_ptr):
            if not packet_ptr:
                return
            callback(user, packet_ptr.contents)

        self._observer_cfunc = PACKET_OBSERVER_CB(_bridge)
        self._lib.cdll.box_set_packet_observer(
            self._h,
            C.cast(self._observer_cfunc, c_void_p),
            self._observer_user,
        )

    def err_str(self, rc: int) -> str:
        return self._lib.cdll.error_message_c(int(rc)).decode()

